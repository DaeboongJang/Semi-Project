package kh.com.photofolio.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import javax.naming.Context;
import javax.naming.InitialContext;

import org.apache.tomcat.dbcp.dbcp2.BasicDataSource;

import kh.com.photofolio.dto.CommentDTO;

public class CommentDAO {

	private BasicDataSource bds;

	public CommentDAO() {
		try {
			Context iCtx = new InitialContext();
			Context envCtx = (Context) iCtx.lookup("java:comp/env");
			bds = (BasicDataSource) envCtx.lookup("jdbc/bds");

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public Connection getConnection() throws Exception {
		return bds.getConnection();
	}
	
	
	// 댓글 등록
	public int insert(CommentDTO dto) {
		String sql = "insert into tbl_comment values(seq_comment.nextval, ?, ?, ?, sysdate)";
		try (Connection con = this.getConnection();
				PreparedStatement pstmt = con.prepareStatement(sql);) {
			
			pstmt.setInt(1, dto.getPost_no());
			pstmt.setString(2, dto.getComment_writer_id());
			pstmt.setString(3, dto.getComment_content());
			
			int rs = pstmt.executeUpdate();
			if (rs != -1) return rs;
			
		} catch(Exception e) {
			e.printStackTrace();
		}
		return -1;
	}
	
	// 댓글 리스트 조회
	public ArrayList<CommentDTO> getCommentList(int post_no){
		String sql = "select * from tbl_comment where post_no=?";
		
		try(Connection con = this.getConnection();
			PreparedStatement pstmt = con.prepareStatement(sql)){
			
			pstmt.setInt(1, post_no);
			ResultSet rs = pstmt.executeQuery();
			
			ArrayList<CommentDTO> list = new ArrayList<>();
			while(rs.next()) {
				int comment_no = rs.getInt("comment_no");
				String id = rs.getString("comment_writer_id");
				String content = rs.getString("comment_content");
				Date comment_createdDate = rs.getDate("comment_createdDate");
				list.add(new CommentDTO(comment_no, post_no, id, content, comment_createdDate));
			}	
			return list;
		}catch(Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
}
