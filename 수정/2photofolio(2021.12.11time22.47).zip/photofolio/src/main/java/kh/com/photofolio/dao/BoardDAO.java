package kh.com.photofolio.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import javax.naming.Context;
import javax.naming.InitialContext;

import org.apache.tomcat.dbcp.dbcp2.BasicDataSource;

import kh.com.photofolio.dto.BoardDTO;
import kh.com.photofolio.dto.FileDTO;

public class BoardDAO {
	private BasicDataSource bds;

	public BoardDAO() {
		try {
			Context iCtx = new InitialContext();
			Context envCtx = (Context) iCtx.lookup("java:comp/env");
			bds = (BasicDataSource) envCtx.lookup("jdbc/bds");

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public Connection getConnection() throws Exception {
		return bds.getConnection();
	}

	// 조회수
	public int post_viewCount(int post_no) {
		String sql = "update tbl_post set post_view_count = post_view_count+1 where post_no=?";

		try (Connection con = this.getConnection(); PreparedStatement pstmt = con.prepareStatement(sql)) {

			pstmt.setInt(1, post_no);
			int rs = pstmt.executeUpdate();
			if (rs != -1)
				return rs;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return -1;
	}

	// 게시글 조회
	public ArrayList<BoardDTO> selectAll() {
		String sql = "select * from tbl_post";

		try (Connection con = this.getConnection(); PreparedStatement pstmt = con.prepareStatement(sql);) {

			ResultSet rs = pstmt.executeQuery();
			ArrayList<BoardDTO> list = new ArrayList<>();
			while (rs.next()) {
				int post_no = rs.getInt("post_no");
				String post_writer = rs.getString("post_writer");
				String post_writer_nickname = rs.getString("post_writer_nickname");
				String post_title = rs.getString("post_title");
				String post_content = rs.getString("post_content");
				Date post_createdDate = rs.getDate("post_createdDate");
				int post_view_count = rs.getInt("post_view_count");
				int category_no = rs.getInt("category_no");
				list.add(new BoardDTO(post_no, post_writer, post_writer_nickname, post_title, post_content,
						post_createdDate, post_view_count, category_no));
			}
			return list;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	// 게시글 삭제
	public int deleteByPost(int post_no) {
		String sql = "delete from tbl_post where post_no = ?";

		try (Connection con = this.getConnection(); PreparedStatement pstmt = con.prepareStatement(sql)) {

			pstmt.setInt(1, post_no);
			int rs = pstmt.executeUpdate();
			if (rs != -1)
				return rs;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return -1;
	}

	// 게시글 수정
	public int modifyByPost(int post_no, String post_title, String post_content) {
		String sql = "update tbl_post set post_title=?, post_content=? where post_no=?";

		try (Connection con = this.getConnection(); PreparedStatement pstmt = con.prepareStatement(sql);) {

			pstmt.setString(1, post_title);
			pstmt.setString(2, post_content);
			pstmt.setInt(3, post_no);

			int rs = pstmt.executeUpdate();
			if (rs != -1)
				return rs;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return -1;
	}

	// 게시글 번호 검색
	public BoardDTO selectBySeq(int seq) {
		String sql = "select * from tbl_post where post_no=?";
		try (Connection con = this.getConnection(); PreparedStatement pstmt = con.prepareStatement(sql);) {

			pstmt.setInt(1, seq);

			ResultSet rs = pstmt.executeQuery();
			if (rs.next()) {
				int post_no = rs.getInt("post_no");
				String post_writer = rs.getString("post_writer");
				String post_writer_nickname = rs.getString("post_writer_nickname");
				String post_title = rs.getString("post_title");
				String post_content = rs.getString("post_content");
				Date post_createdDate = rs.getDate("post_createdDate");
				int post_view_count = rs.getInt("post_view_count");
				int category_no = rs.getInt("category_no");
				return new BoardDTO(post_no, post_writer, post_writer_nickname, post_title, post_content,
						post_createdDate, post_view_count, category_no);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;

	}

	// 시퀀스 값 메서드화
	public int getSequence() {
		String sql = "select seq_post.nextval from dual";
		try (Connection con = this.getConnection(); PreparedStatement pstmt = con.prepareStatement(sql);) {

			ResultSet rs = pstmt.executeQuery();

			if (rs.next())
				return rs.getInt(1);

		} catch (Exception e) {
			e.printStackTrace();
		}
		return -1;
	}

	// 페이징 메서드
	public ArrayList<BoardDTO> getBoardList(int startRange, int endRange) {
		String sql = "select * from" + "(select row_number() over(order by post_no desc) 순위," + "a.* from tbl_post a)"
				+ "where 순위 between ? and ?";
		try (Connection con = this.getConnection(); PreparedStatement pstmt = con.prepareStatement(sql);) {

			pstmt.setInt(1, startRange);
			pstmt.setInt(2, endRange);

			ResultSet rs = pstmt.executeQuery();
			ArrayList<BoardDTO> list = new ArrayList<>();
			while (rs.next()) {
				int post_no = rs.getInt("post_no");
				String post_writer = rs.getString("post_writer");
				String post_writer_nickname = rs.getString("post_writer_nickname");
				String post_title = rs.getString("post_title");
				String post_content = rs.getString("post_content");
				Date post_createdDate = rs.getDate("post_createdDate");
				int post_view_count = rs.getInt("post_view_count");
				int category_no = rs.getInt("category_no");
				list.add(new BoardDTO(post_no, post_writer, post_writer_nickname, post_title, post_content,
						post_createdDate, post_view_count, category_no));
			}
			return list;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	// 총 데이터 수
	public int countAll() {
		String sql = "select count(*) from tbl_post";
		try (Connection con = this.getConnection(); PreparedStatement pstmt = con.prepareStatement(sql);) {
			ResultSet rs = pstmt.executeQuery();

			if (rs.next())
				return rs.getInt(1);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return -1;
	}

	// 게시글 등록
	public int insert(BoardDTO dto) {
		String sql = "insert into tbl_post values(?, ?, ?, ?, ?, sysdate, 0, ?)";
		try (Connection con = this.getConnection(); PreparedStatement pstmt = con.prepareStatement(sql);) {
			pstmt.setInt(1, dto.getPost_no());
			pstmt.setString(2, dto.getPost_writer());
			pstmt.setString(3, dto.getPost_writer_nickname());
			pstmt.setString(4, dto.getPost_title());
			pstmt.setString(5, dto.getPost_content());
			pstmt.setInt(6, dto.getCategory_no());

			int rs = pstmt.executeUpdate();
			if (rs != -1)
				return rs;

		} catch (Exception e) {
			e.printStackTrace();
		}
		return -1;
	}
}
